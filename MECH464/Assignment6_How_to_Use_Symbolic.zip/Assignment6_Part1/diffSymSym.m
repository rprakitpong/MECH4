function [dfdx] = diffSymSym(f, x)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
syms temp_x

dfdx=   simplify(subs(diff(subs(f,x,temp_x), temp_x),temp_x,x));


end

