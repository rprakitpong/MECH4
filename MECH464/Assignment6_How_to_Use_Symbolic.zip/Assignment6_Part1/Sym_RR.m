%% Planar RR Manipulator Dynamics
%  This example shows how to find the Euler-Lagrange equation of a planar
%  RR robot in Christoffel cannonical form using MATLAB symbolic toolbox. 
% 
%%
% <<RR_Robot.PNG>>
%%
%% Defining the variables
syms t real         % Time Variable
syms m1 m2 g real   % Masses of Link and Gravitation
syms l1 l2          % Length of the Link
syms th1(t) th2(t)  % Joint Variable
syms th1_dot(t) th2_dot(t)     % First Order derivative of Joint Variable
syms th1_ddot(t) th2_ddot(t)   % Second order derivative of Joint Variable

%% Defining the Position vector
% We use eqn. (209) and (210) from Ch6_dynamic to get the link positions
% $o_0$, $o_1$ and $o_2$ with respect to the joint variables $\theta_1$ and
% $\theta_2$.
%%
% $o_1-o_0= e^{\theta_1k\times}l_1i$
%%
% $o_2-o_1= e^{\theta_1k\times}e^{\theta_2k\times}l_2i$
%% 
% $\underline{g}$ is defined working in the -j direction
o0=[0;0;0];
o1=[l1*cos(th1); l1*sin(th1); 0];               
o2= simplify(o1+[cos(th1) -sin(th1) 0;          
        sin(th1) cos(th1) 0;
        0 0 1;]* [l2*cos(th2); l2*sin(th2); 0]);
g_vec=[0;-g;0];     
%%  Finding the velocity 
% We can find the velocity of the links by taking the time derivative of
% the position vector as both joint variable are defined as a function of
% time (t).
c1_dot= simplify(diff(o1,t));
c2_dot= simplify(diff(o2,t));
%%  Kinetic Energy and Potential Energy
% We can find the kinetic energy and potential energy using the eqn. (211)
% and  (223) respectively. 
%%
% Kinetic Energy: $T= \frac{1}{2} m_1 \dot{c}_1^T\dot{c}_1+\frac{1}{2} m_2 \dot{c}_2^T\dot{c}_2$
%%
% Potential Energy: $V= -m_1 \underline(g)^T\left(o_1-o_0\right)-m_2 \underline(g)^T\left(o_2-o_0\right)$
%% 
% Lagrangian: $L=T-V$

T=simplify(1/2*m1*(c1_dot.'*c1_dot)+1/2*m2*(c2_dot.'*c2_dot));
V= simplify(-m1*g_vec.'*(o1-o0)- m2*g_vec.'*(o2-o0));
L=simplify(T-V);

%% Euler-Lagrange Equations
% The next step is to find the Euler-Lagrange Equation given by:
%%
% $\frac{d}{dt} \left[ \frac{\partial}{\partial \dot{q}} L\left(q,
% \dot{q}\right)\right] - \frac{\partial}{\partial{q}}L\left(q,
% \dot{q}\right)=\tau^T$
%% 
% This requires finding the partial derivative of $L$ with respect to both
% $\theta$ and $\dot{\theta}$. As Matlab diff function cannot find the
% derivative of an expression with respect to another expression, we have
% to implement our own function to find the derivative. For this purpose,
% I  have implemented the diffSymSym function, which takes two symbolic
% expression y and x and outputs the $\frac{\partial{y}}{\partial{x}}$.



%%
% In the following find the expressions requried for Euler-Lagrange equation
% $\frac{\partial{L}}{\partial{\dot{\theta}_1}}$,
% $\frac{\partial{L}}{\partial{\dot{\theta}_2}}$,
% $\frac{\partial{L}}{\partial{{\theta}_1}}$,
% $\frac{\partial{L}}{\partial{{\theta}_2}}$,
% $\frac{d}{dt}\left[\frac{\partial{L}}{\partial{\dot{\theta}_1}}\right]$
% and
% $\frac{d}{dt}\left[\frac{\partial{L}}{\partial{\dot{\theta}_2}}\right]$
% respectively.
%
dL_dth1_dot= diffSymSym(L, diff(th1,t));
dL_dth2_dot= diffSymSym(L, diff(th2,t));
dL_dth1= diffSymSym(L, th1);
dL_dth2= diffSymSym(L, th2);
dL_dth1_dot_dt=simplify(diff(dL_dth1_dot,t));
dL_dth2_dot_dt=simplify(diff(dL_dth2_dot,t));


tau1=simplify(dL_dth1_dot_dt-dL_dth1);    % Torque applied in Link 1
tau2=simplify(dL_dth2_dot_dt-dL_dth2);    % Torque applied in Link 2
% [tau1; tau2]= [dL_dth1_dot_dt;dL_dth2_dot_dt]-[dL_dth1;dL_dth2];
Tau=[tau1;tau2];                          


%% 
% We can simplify the Euler-Lagrangian equation by substituting the
% time derivative variables with sepearate variables as shown below
Tau=simplify(subs(Tau, {diff(th1, t,t), diff(th1, t),diff(th2, t,t), diff(th2, t)},...
        {th1_ddot, th1_dot, th2_ddot, th2_dot}));
%% Euler-Lagrange Equation
Tau
%% Finding the Mass Matrix
% To find the Mass matrix $\mathbf{D}$, we take the partial derivative of Euler-Lagrange
% with respect to $\ddot{\theta_1}$ and $\ddot{\theta_2}$.
Dq_th1=diffSymSym(Tau, th1_ddot);
Dq_th2=diffSymSym(Tau, th2_ddot);
Dq= [Dq_th1 Dq_th2];    
%%
pretty(Dq)

%%  C in Christoffel Form
% We use eqn. (184) and (185) to calculate the C Matrix in Christoffel Form
% for which we need to find the time derivative of Mass matrix $\mathbf{D}$
% as well as the partial derivative of $\mathbf{D}$ with respect to joint
% variable.

Dq_dot=diff(Dq,t);     %Time Derivative of Mass matrix 
Dq_dot=simplify(subs(Dq_dot, {diff(th1, t,t), diff(th1, t),diff(th2, t,t), diff(th2, t)},...
        {th1_ddot, th1_dot, th2_ddot, th2_dot}));     
%% 
% To find N matrix we need to find the partial derivative of $\mathbf{D}$
% with respect to $\theta_1$ and $\theta_2$. See equation (185) in notes on
% Dynamics
Dq_th1= diffSymSym(Dq,th1);
Dq_th2= diffSymSym(Dq,th2);

N1=([1 0]'*[th1_dot;th2_dot].'*Dq_th1+[0 1]'*[th1_dot;th2_dot].'*Dq_th2);
N2=N1.';
N=N1-N2;

%% 
% We can then find the C matrix using the equation
%%
% $C\left(q,\dot{q}\right)=
% \frac{1}{2}\left[\dot(D)\left(q\right)-N\left(q,\dot{q}\right)\right]$
C=1/2*([Dq_dot]-N);
C= simplify(subs(C, {diff(th1, t,t), diff(th1, t),diff(th2, t,t), diff(th2, t)},...
        {th1_ddot, th1_dot, th2_ddot, th2_dot}));
    
%%
pretty(C)
%% Finding G
% To find the matrix $\mathbf{G}$ we take partial derivative of the
% potential energy with respect to the joint variable.
%%
% 
% $$G\left(q\right)= \frac{\partial V \left(q\right)}{\partial q}$$
% 

G_th1=diffSymSym(V,th1);
G_th2=diffSymSym(V,th2);
G=[G_th1;G_th2];
%%
pretty(G)

%% Function for calculating the partial derivative
 function [dfdx] = diffSymSym(f, x)
 syms temp_x
 dfdx=   simplify(subs(diff(subs(f,x,temp_x), temp_x),temp_x,x));
 end