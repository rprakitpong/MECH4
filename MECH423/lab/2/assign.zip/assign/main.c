#include <msp430.h> 
#include <exercise.h>

int main(void)
{
    exercise1();
    //exercise2();
    //exercise3();
}
